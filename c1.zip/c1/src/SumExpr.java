/** An expression evaluated by adding two operands.
 */

public class SumExpr extends BiExpr {

	/** Constructs a <code>SumExpr</code> with a left and right operand.
	 *  @param leftOp the left operand
	 *  @param rightOp the right operand
	 */
	public SumExpr(Expr leftOp, Expr rightOp){
		super(leftOp, rightOp, "add");
	}
}